
package poepart1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */

public class LoginTest {
    Login logintest1 = new Login("","","","");
    public LoginTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of checkUsername method, of class Login.
     */
    @Test
    public void testCheckUsername() {
        System.out.println("checkUsername");
        String username = "";
        boolean expResult = false;
        boolean result = Login.checkUsername(username);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of validPassword method, of class Login.
     */
    @Test
    public void testValidPassword() {
        System.out.println("validPassword");
        String password = "";
        boolean expResult = false;
        boolean result = Login.validPassword(password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Registeruser method, of class Login.
     */
    @Test
    public void testRegisteruser() {
        System.out.println("Registeruser");
        Login instance = null;
        String expResult = "";
        String result = instance.Registeruser();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of LoginUser method, of class Login.
     */
    @Test
    public void testLoginUser() {
        System.out.println("LoginUser");
        String username2 = "";
        String Userpassword = "";
        Login instance = null;
        boolean expResult = false;
        boolean result = instance.LoginUser(username2, Userpassword);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of ReturnLoginStatus method, of class Login.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("ReturnLoginStatus");
        boolean loginStatus = false;
        Login instance = null;
        String expResult = "";
        String result = instance.ReturnLoginStatus(loginStatus);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTaskName method, of class Login.
     */
    @Test
    public void testSetTaskName() {
        System.out.println("setTaskName");
        String TaskName = "";
        Login instance = null;
        instance.setTaskName(TaskName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTaskName method, of class Login.
     */
    @Test
    public void testGetTaskName() {
        System.out.println("getTaskName");
        Login instance = null;
        String expResult = "";
        String result = instance.getTaskName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTaskDesc method, of class Login.
     */
    @Test
    public void testSetTaskDesc() {
        System.out.println("setTaskDesc");
        String TaskDesc = "";
        Login instance = null;
        instance.setTaskDesc(TaskDesc);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTaskDesc method, of class Login.
     */
    @Test
    public void testGetTaskDesc() {
        System.out.println("getTaskDesc");
        Login instance = null;
        String expResult = "";
        String result = instance.getTaskDesc();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDevName method, of class Login.
     */
    @Test
    public void testSetDevName() {
        System.out.println("setDevName");
        String DevName = "";
        Login instance = null;
        instance.setDevName(DevName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDevName method, of class Login.
     */
    @Test
    public void testGetDevName() {
        System.out.println("getDevName");
        Login instance = null;
        String expResult = "";
        String result = instance.getDevName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDevSur method, of class Login.
     */
    @Test
    public void testSetDevSur() {
        System.out.println("setDevSur");
        String DevSur = "";
        Login instance = null;
        instance.setDevSur(DevSur);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDevSur method, of class Login.
     */
    @Test
    public void testGetDevSur() {
        System.out.println("getDevSur");
        Login instance = null;
        String expResult = "";
        String result = instance.getDevSur();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTaskDur method, of class Login.
     */
    @Test
    public void testSetTaskDur() {
        System.out.println("setTaskDur");
        String TaskDur = "";
        Login instance = null;
        instance.setTaskDur(TaskDur);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTaskDur method, of class Login.
     */
    @Test
    public void testGetTaskDur() {
        System.out.println("getTaskDur");
        Login instance = null;
        String expResult = "";
        String result = instance.getTaskDur();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTaskStat method, of class Login.
     */
    @Test
    public void testSetTaskStat() {
        System.out.println("setTaskStat");
        String TaskStat = "";
        Login instance = null;
        instance.setTaskStat(TaskStat);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTaskStat method, of class Login.
     */
    @Test
    public void testGetTaskStat() {
        System.out.println("getTaskStat");
        Login instance = null;
        String expResult = "";
        String result = instance.getTaskStat();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTaskID method, of class Login.
     */
    @Test
    public void testSetTaskID() {
        System.out.println("setTaskID");
        String TaskID = "";
        Login instance = null;
        instance.setTaskID(TaskID);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTaskID method, of class Login.
     */
    @Test
    public void testGetTaskID() {
        System.out.println("getTaskID");
        Login instance = null;
        String expResult = "";
        String result = instance.getTaskID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTaskNum method, of class Login.
     */
    @Test
    public void testSetTaskNum() {
        System.out.println("setTaskNum");
        String TaskNum = "";
        Login instance = null;
        instance.setTaskNum(TaskNum);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTaskNum method, of class Login.
     */
    @Test
    public void testGetTaskNum() {
        System.out.println("getTaskNum");
        Login instance = null;
        String expResult = "";
        String result = instance.getTaskNum();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setH method, of class Login.
     */
    @Test
    public void testSetH() {
        System.out.println("setH");
        int TotalHo = 0;
        Login instance = null;
        instance.setH(TotalHo);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTotalHo method, of class Login.
     */
    @Test
    public void testGetTotalHo() {
        System.out.println("getTotalHo");
        Login instance = null;
        int expResult = 0;
        int result = instance.getTotalHo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDeveloper method, of class Login.
     */
    @Test
    public void testSetDeveloper() {
        System.out.println("setDeveloper");
        String Developer = "";
        Login instance = null;
        instance.setDeveloper(Developer);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDeveloper method, of class Login.
     */
    @Test
    public void testGetDeveloper() {
        System.out.println("getDeveloper");
        Login instance = null;
        String expResult = "";
        String result = instance.getDeveloper();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of CheckTaskDesc method, of class Login.
     */
    @Test
    public void testCheckTaskDesc() {
        System.out.println("CheckTaskDesc");
        String TaskDesc = "";
        boolean expResult = false;
        boolean result = Login.CheckTaskDesc(TaskDesc);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of CreateTaskId method, of class Login.
     */
    @Test
    public void testCreateTaskId() {
        System.out.println("CreateTaskId");
        Login instance = null;
        instance.CreateTaskId();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of PrintTaskDetails method, of class Login.
     */
    @Test
    public void testPrintTaskDetails() {
        System.out.println("PrintTaskDetails");
        Login instance = null;
        String expResult = "";
        String result = instance.PrintTaskDetails();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of ReturnTotalHours method, of class Login.
     */
    @Test
    public void testReturnTotalHours() {
        System.out.println("ReturnTotalHours");
        Login instance = null;
        int expResult = 0;
        int result = instance.ReturnTotalHours();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of populateArray method, of class Login.
     */
    @Test
    public void testPopulateArray() {
        System.out.println("populateArray");
        Login instance = null;
        instance.populateArray();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayArray method, of class Login.
     */
    
    Login Login1 = new Login("Mike Smith", "Create Login", "5", "to do");
     Login Login2= new Login("Edward Harrison", "Create add features", "8", "doing");
      Login Login3 = new Login("Samantha Paulson", "Create reports", "2", "done");
       Login Login4 = new Login("Glenda Oberholzer", "add arrays", "11", "to do");
    @Test
    public void testDisplayArray() {
       String expectedResults = "";
       
       expectedResults += "Task Developer:" + "Mike Smith";
       expectedResults += "Task Name:" + "Create Login";
       expectedResults += "Task Duration:" + "5";
       expectedResults += "Task Status:" + "to do" +"\n\n";
       
         expectedResults += "Task Developer:" + "Edward Harrison";
       expectedResults += "Task Name:" + "Create add features";
       expectedResults += "Task Duration:" + "8";
       expectedResults += "Task Status:" + "doing" +"\n\n";
       
         expectedResults += "Task Developer:" + "Samantha Paulson";
       expectedResults += "Task Name:" + "Create reports";
       expectedResults += "Task Duration:" + "2";
       expectedResults += "Task Status:" + "done" +"\n\n";
       
         expectedResults += "Task Developer:" + "Glenda Oberholzer";
       expectedResults += "Task Name:" + "add arrays";
       expectedResults += "Task Duration:" + "11";
       expectedResults += "Task Status:" + "to do" +"\n\n";
       
       String actualResults = Login1.DisplayArray();
       //retrieve actual results
       assertEquals(expectedResults, actualResults);
    }

   
    @Test
    public void testStatusArray() {
        System.out.println("StatusArray");
        Login instance = null;
        instance.StatusArray();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Largest method, of class Login.
     */
    @Test
    public void testLargest() {
        boolean actualResults = Login4.Largest("Glenda Oberholzer, 11");
        assertTrue(actualResults);
    }
    @Test
    public void testSearchArray() {
        
   
       boolean actualResults = Login1.SearchArray("Create login");
       //retreives actual expected result
       
       assertTrue(actualResults);
    }
    @Test
    public void testSearchArray2() {
      boolean actualResults = Login3.SearchArray2("Samantha Paulson");
       //retreives actual expected result
       
       assertTrue(actualResults);
    }
    @Test
    public void testRemoveTask() {
       boolean actualResults = Login3.SearchArray2("Create reports");
       //retreives actual expected result
       
       assertTrue(actualResults);
    } 
    @Test
    public void testPart2() {
        System.out.println("Part2");
        Login instance = null;
        instance.Part2();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Stat method, of class Login.
     */
    @Test
    public void testStat() {
        System.out.println("Stat");
        Login instance = null;
        instance.Stat();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Report method, of class Login.
     */
    @Test
    public void testReport() {
        System.out.println("Report");
        Login instance = null;
        instance.Report();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
